# Vectra App

**Author:** Vectra Networks

**Version:**

* 1.0.0

**Supported products:**

* Vectra Cognito

## Using this App

* Install this App on Search Heads
* Set the index containing Vectra Data in the macro `vectra_cognito_index`

## Compatibility

* TA-vectra-cognito >=1.0.1

## Release Notes

* **1.0.0 / 2019-03-09** mbo

  * Initial Release

## Change Log

* **1.0.0 / 2019-03-09** mbo
